def translator(xi, lengthi, web_heighti, foot_heighti, Fx_i, Fy_i, B_val_clipi , B_val_bolt_sheari, B_val_bolt_tensioni , all_frame_bri, all_fuselage_bri, bolt_Ki, t_p2i, t_p3i, verbose = False):
    import numpy as np
    import openturns as ot
    nfwi = xi["nfw"]
    nffi = xi["nff"]
    ti = xi["t"]
    dfwi = xi["dfw"]
    #x is a dict

    #NOTE: Also input bolt locations, their stiffnesses, according to the above obtained optimal design values!!!!!!!!!!!!
    """This block takes in the calues of the optimal design variables and builds the SDP clip 
    input for the analytical evaluation"""

    """---------------------------------------------------------------------------------"""
    """--------------------------FOOOOOOOOOOOOOOOOOOOOOT---------------------------"""
    """---------------------------------------------------------------------------------"""
    #bolt location generator, which is a matrix of x, y locations of foot bolts!!
    foot_bolt_location = np.array([[(lengthi/(nffi+1))*(i+1), foot_heighti/2] for i in range(nffi)])
    foot_bolt_stiffness = np.array([[bolt_Ki]*nffi]).transpose()


    sdp_clip_thickness_p1 = ti
    frame_thickness_p2 = t_p2i
    fuselage_thickness_p3 = t_p3i



    foot_bolt_location_xi = foot_bolt_location[:, 0] # 1xN row vector
    foot_bolt_location_zi = foot_bolt_location[:, 1]
    #print("foot bolts location: ", foot_bolt_location_xi, foot_bolt_location_zi)
    #print("foot_bolt_stiffness = ", foot_bolt_stiffness)
    """====================================FOOT CG CALCULATIONS============================================="""
    Kixi_foot = []
    Kizi_foot = []
    for i in range(len(foot_bolt_stiffness)):
        Kixi_foot = np.append(Kixi_foot, foot_bolt_location_xi[i]*foot_bolt_stiffness[i])
        #print(foot_bolt_location_xi[i]*foot_bolt_stiffness[i])
    for i in range(len(foot_bolt_stiffness)):
        Kizi_foot = np.append(Kizi_foot, foot_bolt_location_zi[i]*foot_bolt_stiffness[i])
        #print(foot_bolt_location_zi[i]*foot_bolt_stiffness[i])

    xg_foot = Kixi_foot.sum()/foot_bolt_stiffness.sum()
    zg_foot = Kizi_foot.sum()/foot_bolt_stiffness.sum()
    #print("foot CG = ", xg_foot, zg_foot)
    """================================================================================="""
    #"""This cg of foot bolts will not be the input for the applied loading on the clip sub-assembly!"""


    foot_bolt_diameter = np.array([[dfwi]*nffi]).transpose()

    foot_bolt_loc_vec = np.array(np.hstack((foot_bolt_location_xi, foot_bolt_location_zi)))
    #print("foot_bolt_loc_vec = ", foot_bolt_loc_vec)

    """================================================================================="""
    """--------------------------WEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEBB-------------------------------------"""
    """================================================================================="""
    """clip_min_x, clip_max_x = [0, length]
    clip_min_y, clip_max_y = [0, web_height]"""

    xFi, yFi, zFi = [xg_foot, 0, zg_foot] #[25, 10] New POA for the clip load Fx, Fy in global coordinates!
    force_poa = np.array([xFi, yFi])

    force_applied = np.array([Fx_i, Fy_i])
    """---------------------------------------------------------------------------------"""
    #print('force_applied = ', force_applied)
    #print('force_poa = ', force_poa, "3D location xF, yF, zF: (", xF, yF, zF, ")")
    """---------------------------------------------------------------------------------"""


    ext_bearing_allowables_clip_frame_fuselage = np.array([B_val_clipi, all_frame_bri, all_fuselage_bri])
    ext_shear_allowables_bolt = np.round(B_val_bolt_sheari, 2)
    ext_tension_allowables_bolt = np.round(B_val_bolt_tensioni, 2)

    #print('ext_shear_allowables_bolt = ', ext_shear_allowables_bolt)
    #print('ext_tension_allowables_bolt = ', ext_tension_allowables_bolt)
    #print('ext_bearing_allowables_clip = ', ext_bearing_allowables_clip_frame_fuselage)

    """---------------------------------------------------------------------------------"""
    """NOTE: all the remaining computations take the len(bolt_stiffness), so keep this input on top!! and you will have all
    solutions automatically calculated!!"""
    bolt_stiffness = np.array([[bolt_Ki]*nfwi]).transpose()
    #print('bolt_stiffness = ', bolt_stiffness)
    """---------------------------------------------------------------------------------"""
    bolt_location = np.array([[(lengthi/(nfwi+1))*(i+1), web_heighti/2] for i in range(nfwi)])


    """============================================================================="""
    bolt_loc_vec = np.array(np.hstack((bolt_location[:, 0], bolt_location[:, 1])))
    #print('bolt_loc_vec = ', bolt_loc_vec[:len(bolt_stiffness)], bolt_loc_vec[len(bolt_stiffness):])



    """---------------------------------------------------------------------------------"""
    bolt_diameter = np.array([[dfwi]*nfwi]).transpose()
    """---------------------------------------------------------------------------------"""


    '''4. for each changes i ninput block, also change the fixed values within the function now!!!'''
    """---------------------------------------------------------------------------------"""
    """--------------------------Input Block Ends-------------------------------------"""
    """---------------------------------------------------------------------------------"""


    """-----------------------------------------OT Integration Block------------------------"""
    """Assembled inputs for OT PyFunc"""
    flat_bolt_location = bolt_loc_vec.flatten()
    flat_foot_bolt_location = foot_bolt_loc_vec.flatten()

    #print("x1, y1 = ", flat_bolt_location)
    flat_bolt_stiffness = bolt_stiffness.flatten()
    flat_foot_bolt_stiffness = foot_bolt_stiffness.flatten()

    flat_bolt_diameter = bolt_diameter.flatten()
    flat_foot_bolt_diameter = foot_bolt_diameter.flatten()

    flat_sdp_clip_thickness_p1 = sdp_clip_thickness_p1
    flat_frame_thickness_p2 = frame_thickness_p2
    flat_fuselage_thickness_p3 = fuselage_thickness_p3





    flat_force_poa = force_poa
    flat_force_applied = force_applied

    flat_ext_bearing_allowables_clip_frame_fuselage = ext_bearing_allowables_clip_frame_fuselage
    flat_ext_shear_allowables_bolt = ext_shear_allowables_bolt
    flat_ext_tension_allowables_bolt = ext_tension_allowables_bolt

    """--------------------OT Point ready for implementation----------------------------------"""

    NNinp = xi["nfw"]
    NNinpfoot = xi["nff"]
    #
    """NN takes in bolt qty from the input block"""
    """Big vector generated below!!!!!"""
    SDP_Clip_Analytical_Input_Op = ot.Point(np.hstack((flat_bolt_location, flat_foot_bolt_location,
                                                    flat_bolt_stiffness, flat_foot_bolt_stiffness,
                                                    flat_bolt_diameter, flat_foot_bolt_diameter,
                                                    flat_sdp_clip_thickness_p1,
                                                    flat_frame_thickness_p2,
                                                    flat_fuselage_thickness_p3,
                                                    flat_force_poa,flat_force_applied,
                                                    flat_ext_bearing_allowables_clip_frame_fuselage,
                                                    flat_ext_shear_allowables_bolt, flat_ext_tension_allowables_bolt,
                                                    NNinp, NNinpfoot)))
    if verbose:
        NN = NNinp
        NNfoot = NNinpfoot
        print("NNinp = ", NNinp, "NNinpfoot = ", NNinpfoot)
        print("SDP_Clip_Analytical_Input =", SDP_Clip_Analytical_Input_Op)
        print("flat_bolt_location =", SDP_Clip_Analytical_Input_Op[0:NN*2])
        print("flat_foot_bolt_location =", SDP_Clip_Analytical_Input_Op[NN*2:(NN*2 + NNfoot*2)])

        print("flat_bolt_stiffness =", SDP_Clip_Analytical_Input_Op[(NN*2 + NNfoot*2):(NN*3 + NNfoot*2)])
        print("flat_foot_bolt_stiffness =", SDP_Clip_Analytical_Input_Op[(NN*3 + NNfoot*2):(NN*3 + NNfoot*3)])

        print("flat_bolt_diameter =", SDP_Clip_Analytical_Input_Op[(NN*3 + NNfoot*3):(NN*4 + NNfoot*3)])
        print("flat_foot_bolt_diameter =", SDP_Clip_Analytical_Input_Op[(NN*4 + NNfoot*3):(NN*4 + NNfoot*4)])

        print("flat_sdp_clip_thickness_p1 =", SDP_Clip_Analytical_Input_Op[(NN*4 + NNfoot*4)])
        print("flat_frame_thickness_p2 =", SDP_Clip_Analytical_Input_Op[(NN*4 + NNfoot*4) + 1])
        print("flat_frame_thickness_p3 =", SDP_Clip_Analytical_Input_Op[(NN*4 + NNfoot*4) + 2])

        print("flat_force_poa =", SDP_Clip_Analytical_Input_Op[(NN*4 + NNfoot*4) + 3:(NN*4 + NNfoot*4) + 5])
        print("flat_force_applied =", SDP_Clip_Analytical_Input_Op[(NN*4 + NNfoot*4) + 5 : (NN*4 + NNfoot*4) + 7])

        print("flat_ext_bearing_allowables_clip_frame_fuselage =", SDP_Clip_Analytical_Input_Op[(NN*4 + NNfoot*4) + 7:(NN*4 + NNfoot*4) + 10])
        print("flat_ext_shear_allowables_bolts =", SDP_Clip_Analytical_Input_Op[(NN*4 + NNfoot*4) + 10])
        print("flat_ext_tension_allowables_bolts =", SDP_Clip_Analytical_Input_Op[(NN*4 + NNfoot*4) + 11])

        print("NNinp, NNinpfoot = ", SDP_Clip_Analytical_Input_Op[-2], SDP_Clip_Analytical_Input_Op[-1])
    
    return SDP_Clip_Analytical_Input_Op