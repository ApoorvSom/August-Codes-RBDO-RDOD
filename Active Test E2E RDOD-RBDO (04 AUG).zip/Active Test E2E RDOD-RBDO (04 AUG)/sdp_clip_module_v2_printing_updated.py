#!/usr/bin/env python
# coding: utf-8

#"""Now this function is ready for integration with the OpenTURNS tool"""
"""Developed in GATE-III"""
# locbvec, Kbvec, diavec, thickp1, thickp2, locFvec, Fappvec, shear_allowables_bolts, bearing_allowables_clip
def sdp_clip_analytical_function_v2_printing(clip_input_list, verbose=True):
    #verbose = true prints all the results in a table, verbose = false, doesn't!!
    import numpy as np
    import matplotlib.pyplot as plt
    import pandas as pd
    
    #clip_input_list = SDP_Clip_Analytical_Input
    clip_input = np.array(clip_input_list)
    NN = int(clip_input[-2])
    NNfoot = int(clip_input[-1])

    locbvec = clip_input[0:NN*2] 
    foot_locbvec = clip_input[NN*2:(NN*2 + NNfoot*2)] 
    #------------------------------------------------------------------------------------
    #------------------------------------------------------------------------------------
    #------------------------------------------------------------------------------------
    if verbose:
        print('locbvec',locbvec)
        print('foot_locbvec',foot_locbvec)
    #------------------------------------------------------------------------------------
    #------------------------------------------------------------------------------------
    #------------------------------------------------------------------------------------
    Kbvec = clip_input[(NN*2 + NNfoot*2):(NN*3 + NNfoot*2)]
    foot_Kbvec = clip_input[(NN*3 + NNfoot*2):(NN*3 + NNfoot*3)]

    diavec = clip_input[(NN*3 + NNfoot*3):(NN*4 + NNfoot*3)]
    foot_diavec = clip_input[(NN*4 + NNfoot*3):(NN*4 + NNfoot*4)]
    thickp1 = clip_input[(NN*4 + NNfoot*4)]
    thickp2 = clip_input[(NN*4 + NNfoot*4) + 1]
    thickp3 = clip_input[(NN*4 + NNfoot*4) + 2]
    locFvec = clip_input[(NN*4 + NNfoot*4) + 3:(NN*4 + NNfoot*4) + 5]
    #Fappvec =  clip_input[4*NN + 5:4*NN + 8]
    Fx = clip_input[(NN*4 + NNfoot*4) + 5]
    Fy = clip_input[(NN*4 + NNfoot*4) + 6]
    print("applied loads; Fxinp = ", Fx, "Fyinp = ", Fy)

    #Fz = clip_input[4*NN + 7]
    bearing_allowables_clip_frame_fuselage = clip_input[(NN*4 + NNfoot*4) + 7:(NN*4 + NNfoot*4) + 10]
    shear_allowable_bolt = clip_input[(NN*4 + NNfoot*4) + 10]
    tension_allowable_bolt = clip_input[(NN*4 + NNfoot*4) + 11]

    """=========================================================================
    ==============================Web Calculations============================================
    ==========================================================================="""
    print("------------------------------------WEB--------------------------------------------")
    Kb = np.array(Kbvec)
    if verbose:
        print('Stiffness Kb = ', Kb)
    locF = np.array(locFvec)

    print("web LocF = ", locF)
    """
    Material properties, loading and point of applicatin taken fixed, no uncertainties in these two levels assumed!
    """

    #------------------------------------------------------------------------------------
    #------------------------------------------------------------------------------------
    #------------------------------------------------------------------------------------
    """changes here locb to locbvec, which is a single long vector of all x coordinates of bolts, 
    and all y coordinates hstacked"""
    bolt_location_xi = locbvec[:NN] # 1xN row vector
    bolt_location_yi = locbvec[NN:]
    #print('locbvec = ', locbvec, type(locbvec))
    #------------------------------------------------------------------------------------
    #------------------------------------------------------------------------------------
    #------------------------------------------------------------------------------------
    if verbose:
        print('bolt_location_xi = ', bolt_location_xi)
        print('bolt_location_yi = ', bolt_location_yi)
    locbTT = np.vstack((bolt_location_xi, bolt_location_yi))
    locb = locbTT.transpose()
    if verbose:
        print('locbTT ', locbTT)
        print('bolt locations = ', locb, type(locb))
    #------------------------------------------------------------------------------------
    #------------------------------------------------------------------------------------
    #------------------------------------------------------------------------------------
    Kixi = []
    Kiyi = []
    for i in range(len(Kb)):
        Kixi = np.append(Kixi, bolt_location_xi[i]*Kbvec[i])
    for i in range(len(Kb)):
        Kiyi = np.append(Kiyi, bolt_location_yi[i]*Kbvec[i])

    xg = Kixi.sum()/Kb.sum()
    yg = Kiyi.sum()/Kb.sum()



    R_Fx = []
    R_Fy = []
    R_M = []
    R_M_x = []
    R_M_y = []

    indice = []
    shear_stress_bolt = []
    SSP1 = []
    SSP2 = []
    MS = []

    r = [] #bolt distance from CG
    for i in range(len(Kb)):
        r = np.append(r, np.linalg.norm(locb[i,:] - np.array([xg, yg])))
    Kiri2 = []
    for i in range(len(Kb)):
        Kiri2 = np.append(Kiri2, np.array([i ** 2 for i in r])[i]*Kb[i])
        #print(Kiri2)



    M_Fy = Fy*(locF[0] - xg)
    M_Fx = Fx*(locF[1] - yg)
    Mnet = M_Fy-M_Fx
    """
    Additional moment input added after transortation to CG. 
    Moment in 3 parts, Fx, Fy and due to M applied moment, all add with sign! NOTE
    Check the sign of the moment and we added additional moment input here from ISAE's doc. Remark: Works well!
    """

    for i in range(len(Kb)):
        R_Fx = np.append(R_Fx, Kb[i]*Fx/Kb.sum())
        R_Fy = np.append(R_Fy, Kb[i]*Fy/Kb.sum())
        R_M = np.append(R_M, (Kb[i]*r[i]*Mnet)/Kiri2.sum())
        #And now, the components of the reaction force due to moment created by the eccentric application of load Fx and Fy
        R_M_x = np.append(R_M_x, (locb[i][1]-yg)*(-Kb[i]*Mnet)/Kiri2.sum()) # bolt_location_yi[i]
        R_M_y = np.append(R_M_y, (locb[i][0]-xg)*(Kb[i]*Mnet)/Kiri2.sum())  #bolt_location_yi[i]
        """Correction made in the components calculation"""
        indice.append(f'Bolt {i+1}: ')


    RmatT = np.array([R_Fx+R_M_x, R_Fy+R_M_y]).transpose() 
    """1. transpose added for single output
       2. other forces removed from RmatrixT, only net force outputs!
       3. resultant array converted into list output"""

    resultant_force_bolt = []
    for k in range(len(Kb)):
        resultant_force_bolt = np.append(resultant_force_bolt, np.sqrt((R_Fx+R_M_x)[k]**2 + (R_Fy+R_M_y)[k]**2))

    for l in range(len(Kb)):
        #MS = np.append(MS, allowableF/resultant_force_bolt[l] - 1)
        """Shear stress calculations added for Reserve Factor RF computations"""
        shear_stress_bolt = np.append(shear_stress_bolt, resultant_force_bolt[l]*4/(np.pi*diavec[l]**2))
        #Shear stress SS in P1 or clip and shear stress SS in P2 or frame
        SSP1 = np.append(SSP1, resultant_force_bolt[l]/(thickp1*diavec[l]))
        SSP2 = np.append(SSP2, resultant_force_bolt[l]/(thickp2*diavec[l]))
    #print(shear_stress)

    RF_bolt_shear = []
    RF_clip_bearing = []
    RF_frame_bearing = []
    for p in range(len(Kb)):
        RF_bolt_shear = np.append(RF_bolt_shear, shear_allowable_bolt/shear_stress_bolt[p])
        RF_clip_bearing = np.append(RF_clip_bearing, bearing_allowables_clip_frame_fuselage[0]/SSP1[p])
        RF_frame_bearing = np.append(RF_frame_bearing, bearing_allowables_clip_frame_fuselage[1]/SSP2[p])
        """for Reserve Factor RF computations"""









    print("------------------------------------FOOT--------------------------------------------")
    """=========================================================================
    ==============================Foot Calculations============================================
    ==========================================================================="""
    foot_Kb = np.array(foot_Kbvec)
    if verbose:
        print('Stiffness Kb = ', foot_Kb)

    """
    Material properties, loading and point of applicatin taken fixed, no uncertainties in these two levels assumed!
    """

    #------------------------------------------------------------------------------------
    #------------------------------------------------------------------------------------
    #------------------------------------------------------------------------------------
    """changes here locb to locbvec, which is a single long vector of all x coordinates of bolts, 
    and all y coordinates hstacked"""
    foot_bolt_location_xi = foot_locbvec[:NNfoot] # 1xN row vector
    foot_bolt_location_yi = foot_locbvec[NNfoot:]
    
    #------------------------------------------------------------------------------------
    #------------------------------------------------------------------------------------
    #------------------------------------------------------------------------------------
    if verbose:
        print('foot_locbvec = ', foot_locbvec, type(foot_locbvec))
        print('foot_bolt_location_xi = ', foot_bolt_location_xi)
        print('foot_bolt_location_yi = ', foot_bolt_location_yi)
    foot_locbTT = np.vstack((foot_bolt_location_xi, foot_bolt_location_yi))
    foot_locb = foot_locbTT.transpose()
    if verbose:
        print('foot_locbTT = ', foot_locbTT)
        print('foot_locb = ', foot_locb)
    foot_R_Fx = []
    foot_R_Fy = []
    indice2 = []
    foot_shear_stress_bolt = []
    foot_tensile_stress_bolt = []
    foot_SSP1 = []
    foot_SSP3 = []
    foot_MS = []

    for ii in range(len(foot_Kb)):
        foot_R_Fx = np.append(foot_R_Fx, foot_Kb[ii]*Fx/foot_Kb.sum())
        foot_R_Fy = np.append(foot_R_Fy, foot_Kb[ii]*Fy/foot_Kb.sum())
        indice2.append(f'Bolt {ii+1}: ')


    foot_RmatT = np.array([foot_R_Fx, foot_R_Fy])
    #print("foot_R_Fy = ", foot_R_Fy)



    foot_resultant_force_bolt = []
    for kk in range(len(foot_Kb)):
        foot_resultant_force_bolt = np.append(foot_resultant_force_bolt, np.sqrt((foot_R_Fx)[kk]**2 + (foot_R_Fy)[kk]**2))

    for ll in range(len(foot_Kb)):
        """Shear stress calculations added for Reserve Factor RF computations"""
        foot_shear_stress_bolt = np.append(foot_shear_stress_bolt, foot_R_Fx[ll]*4/(np.pi*foot_diavec[ll]**2))
        foot_tensile_stress_bolt = np.append(foot_tensile_stress_bolt, foot_R_Fy[ll]*4/(np.pi*foot_diavec[ll]**2))
        #Shear stress SS in P1 or clip and shear stress SS in P2 or frame
        foot_SSP1 = np.append(foot_SSP1, foot_R_Fx[ll]/(thickp1*foot_diavec[ll]))
        foot_SSP3 = np.append(foot_SSP3, foot_R_Fx[ll]/(thickp3*foot_diavec[ll]))
    #print(shear_stress)

    foot_RF_bolt_shear = []
    foot_RF_clip_bearing = []
    foot_RF_fuselage_bearing = []
    foot_RF_bolt_tension = []
    for p in range(len(foot_Kb)):
        foot_RF_bolt_shear = np.append(foot_RF_bolt_shear, shear_allowable_bolt/foot_shear_stress_bolt[p])
        foot_RF_clip_bearing = np.append(foot_RF_clip_bearing, bearing_allowables_clip_frame_fuselage[0]/foot_SSP1[p])
        foot_RF_fuselage_bearing = np.append(foot_RF_fuselage_bearing, bearing_allowables_clip_frame_fuselage[2]/foot_SSP3[p])
        foot_RF_bolt_tension = np.append(foot_RF_bolt_tension, tension_allowable_bolt/foot_tensile_stress_bolt[p])
        """for Reserve Factor RF computations"""
    print("foot_RF_bolt_shear = ", foot_RF_bolt_shear)

    """=============================================================================================
    ======================================RESULTS TABULATION========================================
    ================================================================================================"""
    MS = RF_bolt_shear - 1
    foot_MS = foot_RF_bolt_tension - 1

    #we now create the limit state function for reliability analysis using MCS and FORM:
    """Least MS, most prone to failure. G = -MS, highest G has the most probability of failure, 
    but how much? MCS will quantify it!"""
    '''max_G_limit_state_or_leastMS = -(min(MS))'''
    #must be G <= 0
    Rmatoriginal = np.round(np.array([R_Fx, R_Fy, R_M, R_Fx+R_M_x, R_Fy+R_M_y, resultant_force_bolt, 
                                      shear_stress_bolt, SSP1, SSP2, 
                                      RF_bolt_shear, RF_clip_bearing, RF_frame_bearing, MS]), 2)
    foot_Rmatoriginal = np.round(np.array([foot_R_Fx, foot_R_Fy, foot_resultant_force_bolt, 
                                   foot_shear_stress_bolt, foot_SSP1, foot_SSP3, foot_tensile_stress_bolt,
                                   foot_RF_bolt_shear, 
                                   foot_RF_clip_bearing, 
                                   foot_RF_fuselage_bearing, 
                                   foot_RF_bolt_tension, foot_MS]), 2)
    print(indice2)
    #------------------------------------------------------------------------------------
    #------------------------------------------------------------------------------------
    #------------------------------------------------------------------------------------
    if verbose:
        print('--------------------------------Web Results-----------------------------------')
        print(pd.DataFrame(Rmatoriginal.transpose(), index=indice, 
                           columns=['R_Fx', 'R_Fy', 'R_M', 'net X', 'net Y', 'Resultant F', 
                                    'Shear stress', 'SSP1', 'SSP2', 
                                    'RF_bolt_shear', 'RF_clip_bearing', 'RF_frame_bearing', 'MS bolt = RF-1']))
        print('--------------------------------Foot Results-----------------------------------')
        print(pd.DataFrame(foot_Rmatoriginal.transpose(), index=indice2, 
                           columns=['foot_R_Fx', 'foot_R_Fy', 'foot_Resultant F', 
                                    'foot_Shear stress', 'foot_SSP1', 'foot_SSP3', 'foot_tensile_stress_bolt', 
                                    'foot_RF_bolt_shear', 'foot_RF_clip_bearing', 'foot_RF_fuselage_bearing', 
                                    'foot_RF_bolt_tension', 'foot MS bolt = RF-1']))
        #print("Limit state function G = ", max_G_limit_state_or_leastMS)
        print('-------------------------------------------------------------------')

    #[max_G_limit_state_or_leastMS]
    lis = np.round(RF_bolt_shear.tolist()+RF_clip_bearing.tolist()+RF_frame_bearing.tolist()+
                   foot_RF_bolt_shear.tolist()+foot_RF_clip_bearing.tolist()+foot_RF_fuselage_bearing.tolist()+
                   foot_RF_bolt_tension.tolist(), 2) #resultant_force_bolt.tolist
    lis2 = [min(RF_bolt_shear), min(RF_clip_bearing), min(RF_frame_bearing), min(foot_RF_bolt_shear), min(foot_RF_clip_bearing), min(foot_RF_fuselage_bearing), min(foot_RF_bolt_tension)]
    
    #RF is appended, so it is an array, so we can perform RF - 1 to get MS for each bolt in shear, bearing P1 and bearing P2 at each bolt location
    print("lis2 = ", np.round(lis2, 2))
    return lis2
