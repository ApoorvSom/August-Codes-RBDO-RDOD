"""lis2 = [min(RF_bolt_shear), min(RF_clip_bearing), min(RF_frame_bearing), 
            min(foot_RF_bolt_shear), min(foot_RF_clip_bearing), min(foot_RF_fuselage_bearing), min(foot_RF_bolt_tension)]"""

def sdp_bolt_shear(clip_input_list, verbose=False):
    from sdp_clip_module_v2_updated import sdp_clip_analytical_function_v2
    old_function = sdp_clip_analytical_function_v2(clip_input_list)
    return [(old_function[0])]

def sdp_clip_bearing(clip_input_list, verbose=False):
    from sdp_clip_module_v2_updated import sdp_clip_analytical_function_v2
    old_function = sdp_clip_analytical_function_v2(clip_input_list)
    return [(old_function[1])]

def sdp_frame_bearing(clip_input_list, verbose=False):
    from sdp_clip_module_v2_updated import sdp_clip_analytical_function_v2
    old_function = sdp_clip_analytical_function_v2(clip_input_list)
    return [(old_function[2])]

def sdp_foot_bolt_shear(clip_input_list, verbose=False):
    from sdp_clip_module_v2_updated import sdp_clip_analytical_function_v2
    old_function = sdp_clip_analytical_function_v2(clip_input_list)
    return [(old_function[3])]

def sdp_foot_clip_bearing(clip_input_list, verbose=False):
    from sdp_clip_module_v2_updated import sdp_clip_analytical_function_v2
    old_function = sdp_clip_analytical_function_v2(clip_input_list)
    return [(old_function[4])]

def sdp_fuselage_bearing(clip_input_list, verbose=False):
    from sdp_clip_module_v2_updated import sdp_clip_analytical_function_v2
    old_function = sdp_clip_analytical_function_v2(clip_input_list)
    return [(old_function[5])]

def sdp_foot_bolt_tension(clip_input_list, verbose=False):
    from sdp_clip_module_v2_updated import sdp_clip_analytical_function_v2
    old_function = sdp_clip_analytical_function_v2(clip_input_list)
    return [(old_function[6])]
